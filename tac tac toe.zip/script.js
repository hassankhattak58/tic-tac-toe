
// Which Player Turn is 

let turn = "X";
let indicator = document.getElementById("turn-indicator");

// Initilaize Board as Empty

let board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
]

// Function for Restart 
function restart() {
    board = [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ];
    turn = "X";
    indicator.innerText = turn;
    let boxes = document.querySelectorAll(".col");

    for (let i = 0; i < boxes.length; i++) {
       boxes[i].innerText = "";
    }
}

// Function To Check Win 

function checkWin() {
    // First Check Row 
    for (let i = 0; i < 3; i++) {
        if (board[i][0] === board[i][1] && board[i][1] === board[i][2] && board[i][0] !== "") {
            return true;
        }
    }

    // Second Check Column
    for (let i = 0; i < 3; i++) {
        if (board[0][i] === board[1][i] && board[1][i] === board[2][i] && board[0][i] !== "") {
            return true;
        }
    }

    // Check Diagnols 
    if (board[0][0] === board[1][1] && board[1][1] === board[2][2] && board[0][0] !== "") {
        return true;
    }

    if (board[0][2] === board[1][1] && board[1][1] === board[2][0] && board[0][2] !== "") {
        return true;
    }

    return false;
}

function checkDraw() {

    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            if (board[i][j] == "") {
                return false;
            }
        }

    }

    return true;
}

// Function to Make Move

function makeMove(row, col, box) {
    if (board[row][col] == "") {
        board[row][col] = turn;
        box.innerText = turn;
        // Check if someone won or not 
        if (checkWin()) {
            alert(turn + " won the Game!");
            indicator.innerText = turn + " won the Game!";
        }

        // Check if Game is drawn 
        if (checkDraw()) {
            alert("It's a Draw!");
            indicator.innerText = "Drawn";
        }


        turn = turn === "X" ? "0" : "X";
        indicator.innerText = turn;

    } else {
        alert("Invalid Move");
    }

}